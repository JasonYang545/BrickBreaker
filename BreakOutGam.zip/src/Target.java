import processing.core.PApplet;

public class Target extends Block {
	
	// constructor makes target with specific position and speed
    public Target(int inrow, int incol) {
    	row = inrow;
    	col = incol; 
    	w=50; 
    	h=20;
    	x = (col-1)*(50+5); 
    	y = (row-1)*(20+3);
    	dx = 5; 
    	dy=0;
    }
    
	@Override
	public void update() {
		x = x+dx; 	
	}
	
	@Override
	public void draw(PApplet p) {
		switch (this.row) {
		case 1: p.fill(0,255,0); break;
		case 2: p.fill(255,0,0); break;
		case 3: p.fill(0,0,255); break;
		case 4: p.fill(255,255,255); break;
		case 5: p.fill(255,255,0); break;
		default: p.fill(0,0,0); break;
	}
		p.rect(x, y, w, h);
	}
	
	// figures out if missile has hit barrier
	@Override
	public boolean collide(Missle m) {
		if (m.x- m.w/2 > this.x + this.w) {
			return false;
			}  //left
		if (m.x+ m.w/2 < this.x  ) {
			return false;
			}  //right
		if (m.y- m.h/2 > this.y + this.h) {
			return false;
			}  //bottom
		if (m.y+ m.w/2 < this.y  ) {
			return false;
			}  //top
		return true;
		}
}
