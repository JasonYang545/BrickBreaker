import java.util.ArrayList;

import processing.core.PApplet;

public class MainClass extends PApplet {
	// Declarations
	public int nCols = 1200, nRows = 600, score =0;
	ArrayList<Entity> entities = new ArrayList<Entity>();
	Block b; Target t; Missle m; Barrier barr; Base base;
	
	public void setup(){
		// makes screen size
		size(nCols,nRows);
		// targets 
		for (int row  =1; row<=5; row++ ) {
			for (int col  =1; col<=10; col++ ) {
				t = new Target(row,col);
				// add target object to entity 
		        entities.add(t);
		    }
		}
		// barriers
		for (int row  =1; row<=6; row++ ) {
		    barr = new Barrier(row);  
		    entities.add(barr);
		}
		//base and missile
		base = new Base();
		m = new Missle(base,nCols,nRows);
		entities.add(base);
		entities.add(m);
		//All added to entities 
		}// end setup
	
	public void draw() { 
		EdgeCheck();  // blocks change direction when hitting edge
		// Tells entity to update: x,y,dX,dY
		for (Entity myentity: entities) {
		     myentity.update();
		}
		// Looks at each entity in ArrayList
		for (Entity myentity: entities) {
			// Block is either a barrier or target
			// checks if region of barrier checks missile region, remove target if yes
			// if barrier, make missile go other direction
			if (myentity instanceof  Block) {
		    	b = (Block) myentity;
		        if (b.collide(m)) {
		        	// For Q8.1, instead of removing just entity, do a loop thru all 
		        	// entities looking for targets, if same col, remove too
		        	if (b instanceof Target) {
		        		entities.remove(myentity);//remove 2nd half
		        		score++;
		        		// sets missile on base
			        	if (m.dy <0) {
			        		m.setOnBase();
			        	}
			        	// otherwise bounce
			        	else {
			        		score+=2;
			        		m.dy=-m.dy; 
			        	}
			        	break; 
		        	}
		        	if (b instanceof Barrier) {
		        		// bounce off barrier
		        		m.dx = -m.dx; 
		        		m.dy=-m.dy;
		        	}
		        	// put missile on base if collide
		        	if (b instanceof Base) {
		        		m.setOnBase();
		        	}
		        }
		    }
		}
		// redraw updated screen
		background(200);
		for (Entity myentity: entities) {
		    myentity.draw(this) ;
		}
	}
	
	// method to register user mouse click -> X,Y pos
	public void mouseClicked(){
		// left half
		if ((mouseX <= base.x+(base.w/2)) && (mouseX >= base.x)) {
			if (mouseY <= 510 && mouseY >=500) {
				base.w += 10;
			}
		}
		// right half
		if ((mouseX >= base.x+(base.w/2)) && (mouseX <= base.x+base.w)) {
			if (mouseY <= 510 && mouseY >=500) {
				base.w -= 10;
			}
		}
         System.out.println(mouseX + "-" + mouseY);
         // For Q8.2, bring in the block from target and check if missile is clicked
         // increase side at end if all is true	
	}
	
	// method for arrow key press
	public void keyPressed() { 
		if (keyCode == UP) {
			m.fired = true;}	
		// move base right 
		if (keyCode == RIGHT) {
			base.x+= 5;
			if (!m.fired) {m.x+=5;}}
		// move base left
		if (keyCode == LEFT) {
			base.x-= 5;
			if (!m.fired) {m.x-=5;}}
	}
					 
	//  For Q 8, if hit, no loop just flag false and flip the second if
	// checks if any entity his screen edge 
	public void EdgeCheck() {
		boolean edgeflag = false;
		for (Entity myentity: entities) {
		    if (myentity instanceof Block) {
		    	b = (Block) myentity;
		    	// if u hit the edge, switch to true;
		        if ( b.x + b.w > nCols) {
		        	edgeflag = true;break;}
		        if ( b.x <0) {
		        	edgeflag = true;break;}
		    }	
	    }
		// if barrier or target hits edge, bounce
		if (edgeflag) {
			for (Entity myentity: entities) {
			    if (myentity instanceof  Target )  {
			    	b = (Block) myentity;
			    	b.dx = -b.dx; 
			    	//b.dx *= 1.2;
			    	b.y +=5;
			    }	
		    } 
		}
	}
}
